#!/usr/bin/perl -w
use List3_tree_d_sem;
use Parse::Eyapp::Node;

$parser = new List3_tree_d_sem();
$parser->Run;
