#!/usr/bin/perl -w
use strict;
use CalcUsingTail;

CalcUsingTail->main();
