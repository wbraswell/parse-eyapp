#!/usr/bin/perl -w
use Lhs1;

Lhs1->new->YYParse;
