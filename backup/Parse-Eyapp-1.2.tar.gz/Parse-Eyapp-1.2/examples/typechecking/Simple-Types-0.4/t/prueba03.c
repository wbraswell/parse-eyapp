int a,b,e[10];

g() {}

int f(char c) {
char d;
 c = 'X';
 e[d] = 'A'+c;
 { 
   int d;
   d = a + b;
 }
 a = b * 2;
 return c;
}

