int f() {
  int a[30];

  return a;
}
