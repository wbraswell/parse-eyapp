typedef struct a { char x; } ex1, *ptr1;

typedef struct b { char x; } ex2, *ptr2; 

main() {
  ptr1 x,y;
  ptr2 z, t;

  z = t;
  x = y;
}
