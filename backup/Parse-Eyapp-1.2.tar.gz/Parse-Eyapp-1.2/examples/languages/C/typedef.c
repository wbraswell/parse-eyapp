typedef enum {FALSE=0, TRUE} boolean;

main ()
{
  boolean flag = TRUE;
}
  

