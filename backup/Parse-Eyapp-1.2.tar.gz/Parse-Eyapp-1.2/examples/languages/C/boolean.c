/* first time boolean in lowercase */
typedef enum {false, true} boolean;

