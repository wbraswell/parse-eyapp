typedef enum {false, true} boolean[2];

