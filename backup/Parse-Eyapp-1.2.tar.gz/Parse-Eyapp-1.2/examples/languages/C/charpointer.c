typedef char *string;
     
main()
{
   string text = "Thunderbird";
 
   printf("%s\n", text);
}

